import atexit
import glob
import math
import os
import gc
import signal
import keras
import matplotlib.lines as mlines
import matplotlib.pyplot as plt
import numpy as np
import optuna
import pandas as pd
import tensorflow as tf
import logging
from kennard_stone import train_test_split
from tensorflow.keras import backend as K
from optuna_integration import TFKerasPruningCallback
from packaging import version
from sklearn.metrics import root_mean_squared_error, r2_score

optuna.logging.set_verbosity(optuna.logging.INFO)
optuna.logging.enable_default_handler()
logger = logging.getLogger("optuna")
logger.setLevel(logging.INFO)

class Optimization:
    """
    Manages an optimization process for a machine learning model.

    This class is designed to manage and execute the optimization process
    for a machine learning model. It provides attributes to initialize
    specific parameters such as study name, random seed, patience, number
    of epochs, number of optimization trials, and dataset. It facilitates
    an organized approach to model tuning and experimentation.

    :ivar epochs: Number of epochs to train the model.
    :type epochs: int
    :ivar n_trials: Number of optimization trials to perform.
    :type n_trials: int
    :ivar patience: Number of consecutive epochs without improvement
        allowed before stopping training.
    :type patience: int
    :ivar seed: Random seed value to ensure reproducibility.
    :type seed: int
    :ivar study_name: Name of the study for tracking optimization results.
    :type study_name: str
    :ivar data: Dataset to be used for model training and validation.
    :type data: Any
    :ivar model_file: Path to save or load the trained model.
    :type model_file: str
    """
    def __init__(self, study_name, seed, patience, epochs, n_trials, train_data, test_data):
        self.epochs = epochs
        self.n_trials = n_trials
        self.patience = patience
        self.seed = seed
        self.study_name = study_name
        self.train_data = train_data
        self.test_data = test_data
        self.model_file = ""


def initialize(study_name, seed, patience, epochs, n_trials, train_data, test_data):
    """
    Initializes the global optimization process for hyperparameter tuning using the
    provided input parameters. Validates TensorFlow version compatibility and ensures
    the unique naming of the optimization study. Handles the creation of the global
    hybrid optimization object and performs initializations necessary for the process.

    :param study_name: Name of the hyperparameter optimization study file.
    :param seed: Seed value for ensuring reproducibility of results.
    :param patience: Number of epochs with no improvement after which training is stopped.
    :param epochs: Total number of training epochs.
    :param n_trials: Number of hyperparameter optimization trials to perform.
    :param data: Dataset used for training and evaluation during optimization.
    :return: None
    """
    global hpoptimize
    hpoptimize = Optimization(study_name, seed, patience, epochs, n_trials, train_data, test_data)

    # Tensorflow Version Überprüfen
    if version.parse(tf.__version__) < version.parse("2.11.0"):
        raise RuntimeError("tensorflow>=2.11.0 is required for this example.")
    # Ask user for Study name
    if os.path.isfile(hpoptimize.study_name + ".sqlite3") is True:
        print("This file already exists! Choose a different name for the Study")
        hpoptimize.study_name = input("Study name: ")
    hpoptimize.model_file = 'checkpoint.model.keras'


# Global variable to store the current model
current_model = None


def save_model_on_interrupt(signum, frame):
    """
    Handles the interrupt signal to save the current model if it exists.

    This function is designed to be invoked when an interrupt signal is
    received, such as a SIGINT (e.g., triggered by pressing Ctrl+C). It
    checks if a global variable `current_model` is defined, and if so,
    it saves the model to a file named 'interrupted_model.keras'.
    If no model is available, it notifies the user that there is no model
    to save.

    :param signum: Signal number indicating the received signal.
    :type signum: int
    :param frame: Current stack frame at the time of interruption.
    :type frame: types.FrameType
    """
    global current_model
    if current_model:
        print("\nProgram interrupted. Saving the current model...")
        current_model.save("interrupted_model.keras")
        print("Model saved as 'interrupted_model.keras'.")
    else:
        print("\nNo model to save.")


# Register the signal handler
signal.signal(signal.SIGINT, save_model_on_interrupt)

def parse_mplstyle(style_file_path):
    """
    Parses a Matplotlib style file (.mplstyle) and converts it into a dictionary
    of style settings. Each key-value pair represents a specific style setting
    defined in the file. Empty lines and comments in the file are ignored during
    parsing.

    :param style_file_path: Path to the Matplotlib style file (.mplstyle) that
        needs to be parsed.

    :return: Dictionary containing the style settings parsed from the file. Each
        key corresponds to a setting, and its value represents the associated
        property.
    :rtype: dict
    """
    with open(style_file_path, 'r') as file:
        style_settings = {}
        for line in file:
            # Ignoriere Kommentare und leere Zeilen
            if line.strip() and not line.strip().startswith('#'):
                key, value = line.strip().split(':', 1)
                style_settings[key.strip()] = value.strip()
    return style_settings


# Plotte History und prediction Value vs. true Value
def plot_graphs(history, trial_number, y_train, train_predict, y_val, val_predict, y_test, test_predict):
    """
    Plots and saves various graphs to evaluate model performance, including RMSE history,
    Huber loss history, and model predictions versus actual values.

    Adjustments are necessary for different data sets:
    - The limits for the x- and y-axes
    - The axis labels

    :param history: Training history object containing the metric and loss values for
                    both training and validation datasets.
    :type history: tf.keras.callbacks.History
    :param trial_number: Identifier for the specific trial to label saved plots.
    :type trial_number: int
    :param y_train: True values for the training dataset for comparison with predictions.
    :type y_train: numpy.ndarray
    :param train_predict: Predicted values corresponding to the training dataset.
    :type train_predict: numpy.ndarray
    :param y_val: True values for the validation dataset for comparison with predictions.
    :type y_val: numpy.ndarray
    :param val_predict: Predicted values corresponding to the validation dataset.
    :type val_predict: numpy.ndarray
    :param y_test: True values for the test dataset for comparison with predictions.
    :type y_test: numpy.ndarray
    :param test_predict: Predicted values corresponding to the test dataset.
    :type test_predict: numpy.ndarray
    :return: None
    """

    #IKV Stil für Grafiken
    plt.rcdefaults
    plt.style.use(["IKV.mplstyle"])

    # Plot History RMSE
    fig, ax = plt.subplots()
    plt.plot(history.history["val_root_mean_squared_error"], label="Validationsdaten")
    plt.plot(history.history["root_mean_squared_error"], label="Trainingsdaten")
    ax.set_ylim(bottom=0)
    ax.set_xlim(left=0)
    ax.set_ylabel("RMSE [mm/s²]")
    ax.set_xlabel("Epoche  [-]")
    ax.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(os.path.join(hpoptimize.paths["plots"], f"{trial_number}_RMSE.png"))
    plt.close()

    # Plot History Huber
    fig, ax = plt.subplots()
    plt.plot(history.history["val_loss"], label="Validationsdaten")
    plt.plot(history.history["loss"], label="Trainingsdaten")
    ax.set_ylim(bottom=0)
    ax.set_xlim(left=0)
    ax.set_ylabel("Huber [-]")
    ax.set_xlabel("Epoche  [-]")
    ax.legend(loc='upper right')
    plt.tight_layout()
    plt.savefig(os.path.join(hpoptimize.paths["plots"], f"{trial_number}_Huber_Loss.png"))
    plt.close()

    # Plot Predict vs True
    plt.scatter(y_train, train_predict, label="Trainingsdaten")
    plt.scatter(y_test, test_predict, label="Testdaten")
    plt.scatter(y_val, val_predict, label="Validationsdaten")
    ax = plt.gca()
    ax.legend(loc='upper left')
    plt.xlabel('Reale Fließfronten [mm/s²]', fontsize=15) # Adjust Label
    ax.set_xlim([0,100]) # Adjust limit for the x-Axis
    ax.set_xticks(np.arange(0,100, step=10)) # Adjust limit for the steps on the x-Axis
    plt.ylabel('Vorhergesagte Fließfronten [mm/s²]', fontsize=15) # Adjust label
    ax.set_ylim([0,100])  # Adjust limit for the y-Axis
    ax.set_yticks(np.arange(0,100, step=10)) # Adjust limit for the steps on the y-Axis
    line = mlines.Line2D([0, 1], [0, 1], color="black", alpha=0.8)
    transform = ax.transAxes
    line.set_transform(transform)
    ax.add_line(line)
    plt.tight_layout()
    plt.savefig(os.path.join(hpoptimize.paths["plots"], f"{trial_number}_Predict_vs._True.png"))
    plt.close()


def apply_custom_chart_style(chart_all_data, y_train, y_val, y_test, train_predict, val_predict, test_predict, combined_df, worksheet_all_data):
    """
    Applies a custom chart style to the given chart object. This function formats the chart by
    setting titles, axes, plot area, chart area, and gridlines appearance based on calculated
    maximum values derived from true and predicted data.

    :param chart_all_data: The chart object to which the styling is applied.
    :param y_train: True values for the training dataset.
    :param y_val: True values for the validation dataset.
    :param y_test: True values for the testing dataset.
    :param train_predict: Predicted values for the training dataset.
    :param val_predict: Predicted values for the validation dataset.
    :param test_predict: Predicted values for the testing dataset.
    :param combined_df: Combined DataFrame used for deriving insights for styling.
    :param worksheet_all_data: Worksheet object used for displaying the chart.
    :return: None
    """
    max_value = max(
        y_train.max(), y_val.max(), y_test.max(),
        train_predict.max(), val_predict.max(), test_predict.max())
    max_value_rounded = math.ceil(max_value)

    chart_all_data.set_title({
        "name": "True vs Predicted Values",
        "name_font": {"size": 14, "bold": True, "color": "black"}
    })

    chart_all_data.set_x_axis({
        "name": "True Values [mm]",
        "name_font": {"size": 12, "bold": False, "color": "black"},
        "num_font": {"size": 10, "color": "black"},
        "line": {"color": "black", "width": 1.0},
        "major_gridlines": {"visible": True, "line": {"color": "black", "width": 0.5}},
        "min": 0,
        "max": max_value_rounded
    })

    chart_all_data.set_y_axis({
        "name": "Predicted Values [mm]",
        "name_font": {"size": 12, "bold": False, "color": "black"},
        "num_font": {"size": 10, "color": "black"},
        "line": {"color": "black", "width": 1.0},
        "major_gridlines": {"visible": True, "line": {"color": "black", "width": 0.5}},
        "min": 0,
        "max": max_value_rounded
    })

    chart_all_data.set_plotarea({
        "border": {"color": "black", "width": 0.5},
        "fill": {"color": "white"}
    })
    chart_all_data.set_chartarea({
        "border": {"color": "black", "width": 0.5},
        "fill": {"color": "white"}
    })


def save_trial_results_with_dynamic_style(trial_number, y_train, train_predict, y_test, test_predict, y_val, val_predict, history):
    """
    Saves the results of a trial with dynamically generated styles to a structured Excel file. The function
    creates detailed sheets containing data points and training/validation/test metrics, and it generates
    custom scatter plots with highlighting for comparison.

    :param trial_number: The unique identifying number of the trial.
    :param y_train: The true values for the training dataset.
    :param train_predict: The predicted values corresponding to the training dataset.
    :param y_test: The true values for the testing dataset.
    :param test_predict: The predicted values corresponding to the testing dataset.
    :param y_val: The true values for the validation dataset.
    :param val_predict: The predicted values corresponding to the validation dataset.
    :param history: The training history object, containing loss and RMSE metrics for each epoch.
    :return: None
    """
    """output_folder = f"Ergebnisse/{hpoptimize.study_name}"
    os.makedirs(output_folder, exist_ok=True)
    output_file = f"{output_folder}/Trial_{trial_number}.xlsx"""

    output_file = os.path.join(hpoptimize.paths["metrics"], f"Trial_{trial_number}.xlsx")

    with pd.ExcelWriter(output_file, engine="xlsxwriter") as writer:
        train_df = pd.DataFrame({
            "True Values Train": y_train.to_numpy().flatten(),
            "Predictions Train": train_predict.flatten()
        })
        valid_df = pd.DataFrame({
            "True Values Validation": y_val.to_numpy().flatten(),
            "Predictions Validation": val_predict.flatten()
        })
        test_df = pd.DataFrame({
            "True Values Test": y_test.to_numpy().flatten(),
            "Predictions Test": test_predict.flatten()
        })

        combined_df = pd.concat([train_df, valid_df, test_df], axis=1)
        combined_df.to_excel(writer, sheet_name="All_Data", index=False, header=True)

        history_df = pd.DataFrame({
            "Epoch": range(1, len(history.history["loss"]) + 1),
            "Train RMSE": history.history["root_mean_squared_error"],
            "Validation RMSE": history.history["val_root_mean_squared_error"],
            "Train Loss": history.history["loss"],
            "Validation Loss": history.history["val_loss"]
        })
        history_df.to_excel(writer, sheet_name="Metrics", index=False)

        workbook = writer.book
        worksheet_all_data = writer.sheets["All_Data"]
        chart_all_data = workbook.add_chart({"type": "scatter"})

        for dataset, color, columns in zip(
                ["Train", "Validation", "Test"],
                ["#95BB20", "#717E86", "#00354E"],
                [("True Values Train", "Predictions Train"),
                 ("True Values Validation", "Predictions Validation"),
                 ("True Values Test", "Predictions Test")]
        ):
            start_row = 1
            end_row = len(combined_df)
            chart_all_data.add_series({
                "name": f"{dataset} Data",
                "categories": ["All_Data", start_row, combined_df.columns.get_loc(columns[0]), end_row,
                                combined_df.columns.get_loc(columns[0])],
                "values": ["All_Data", start_row, combined_df.columns.get_loc(columns[1]), end_row,
                           combined_df.columns.get_loc(columns[1])],
                "marker": {"type": "circle", "size": 6, "fill": {"color": color}, "border": {"none": True}}
            })

        max_value = math.ceil(max(
            y_train.max(), y_val.max(), y_test.max(),
            train_predict.max(), val_predict.max(), test_predict.max()))

        # 45° Linie
        worksheet_all_data.write_row(len(combined_df) + 1, 0, [0, 0])
        worksheet_all_data.write_row(len(combined_df) + 2, 0, [max_value, max_value])
        chart_all_data.add_series({
            "name": None,
            "categories": ["All_Data", len(combined_df) + 1, 0, len(combined_df) + 2, 0],
            "values":     ["All_Data", len(combined_df) + 1, 1, len(combined_df) + 2, 1],
            "line": {"color": "black", "dash_type": "dash", "width": 1.0},
            "marker": {"type": "none"},
        })

        # Vertikale Linie x=max
        worksheet_all_data.write_row(len(combined_df) + 3, 0, [max_value, 0])
        worksheet_all_data.write_row(len(combined_df) + 4, 0, [max_value, max_value])
        chart_all_data.add_series({
            "categories": ["All_Data", len(combined_df) + 3, 0, len(combined_df) + 4, 0],
            "values":     ["All_Data", len(combined_df) + 3, 1, len(combined_df) + 4, 1],
            "line": {"color": "black", "width": 1.0},
            "marker": {"type": "none"},
            "name": None
        })

        # Horizontale Linie y=max
        worksheet_all_data.write_row(len(combined_df) + 5, 0, [0, max_value])
        worksheet_all_data.write_row(len(combined_df) + 6, 0, [max_value, max_value])
        chart_all_data.add_series({
            "categories": ["All_Data", len(combined_df) + 5, 0, len(combined_df) + 6, 0],
            "values":     ["All_Data", len(combined_df) + 5, 1, len(combined_df) + 6, 1],
            "line": {"color": "black", "width": 1.0},
            "marker": {"type": "none"},
            "name": None
        })

        """chart_all_data.set_legend({
            "position": "right",
            "font": {"color": "black", "size": 10},
            "overlay": False
        })"""

        apply_custom_chart_style(chart_all_data, y_train, y_val, y_test, train_predict, val_predict, test_predict, combined_df, worksheet_all_data)
        worksheet_all_data.insert_chart("I2", chart_all_data)



# Train-Test Erstellung mit Kennard Stone
def data():
    """
    Loads data from a specified Excel file, prepares input and output features,
    normalizes the data, and splits it into training, validation, and test sets.

    This function processes a dataframe by segregating input and output
    features, normalizing as needed, and performing a train-test split.
    Additionally, it separates validation data from the training set for model
    evaluation purposes.

    :raises FileNotFoundError: If the specified data file does not exist.
    :raises ValueError: If the dataframe structure does not match the
       expected format or the train-test split ratios are invalid.

    :return: A tuple containing the following elements:
        - `x_train`: Training input data.
        - `y_train`: Training output data.
        - `x_val`: Validation input data.
        - `y_val`: Validation output data.
        - `x_test`: Test input data.
        - `y_test`: Test output data.
    :rtype: Tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series,
        pd.DataFrame, pd.Series]
    """
    # DataFrame Laden
    holdout_filename = hpoptimize.test_data
    pool_filename = hpoptimize.train_data

    holdout_df = pd.read_excel(holdout_filename)
    pool_df = pd.read_excel(pool_filename)

    holdout_datain = holdout_df.iloc[:, :10]  # Spalten Input
    holdout_dataout = holdout_df.iloc[:, -2]  # Spalten Output
    pool_datain = pool_df.iloc[:, :10]  # Spalten Input
    pool_dataout = pool_df.iloc[:, -2]  # Spalten Output

    # Normalisieren
    hpoptimize.data_min_x = pool_datain.min().values.astype(float)
    hpoptimize.data_max_x = pool_datain.max().values.astype(float)
    hpoptimize.data_min_y = float(pool_dataout.min())
    hpoptimize.data_max_y = float(pool_dataout.max())

    pool_df_in = (pool_datain - hpoptimize.data_min_x) / (hpoptimize.data_max_x - hpoptimize.data_min_x)
    pool_df_out = (pool_dataout - hpoptimize.data_min_y) / (hpoptimize.data_max_y - hpoptimize.data_min_y)
    holdout_df_in = (holdout_datain - hpoptimize.data_min_x) / (hpoptimize.data_max_x - hpoptimize.data_min_x)
    holdout_df_out = (holdout_dataout - hpoptimize.data_min_y) / (hpoptimize.data_max_y - hpoptimize.data_min_y)

    # Kennard-Stone Aufteilung
    x_train, x_val, y_train, y_val = train_test_split(
        pool_df_in,
        pool_df_out,
        test_size=0.111111)
    x_test, y_test = holdout_df_in, holdout_df_out

    return x_train, y_train, x_val, y_val, x_test, y_test

def unnormalize_x(x_norm):
    return x_norm * (hpoptimize.data_max_x - hpoptimize.data_min_x) + hpoptimize.data_min_x

def unnormalize_y(y_norm):
    return y_norm * (hpoptimize.data_max_y - hpoptimize.data_min_y) + hpoptimize.data_min_y

def save_split_data(x_train, y_train, x_val, y_val, x_test, y_test):
    """
    Speichert die Trainings-, Validierungs- und Testdaten in eine separate Excel-Datei
    unabhängig vom Trial, um Nachvollziehbarkeit zu gewährleisten.

    :param x_train: Trainings-Eingabedaten
    :param y_train: Trainings-Zieldaten
    :param x_val: Validierungs-Eingabedaten
    :param y_val: Validierungs-Zieldaten
    :param x_test: Test-Eingabedaten
    :param y_test: Test-Zieldaten
    """
    output_folder = f"Ergebnisse/{hpoptimize.study_name}"
    os.makedirs(output_folder, exist_ok=True)
    file_path = os.path.join(hpoptimize.paths["data"], f"Split_Daten_{hpoptimize.study_name}.xlsx")

    with pd.ExcelWriter(file_path, engine="xlsxwriter") as writer:
        # Training
        train_df = pd.concat([x_train.reset_index(drop=True), y_train.reset_index(drop=True)], axis=1)
        train_df.to_excel(writer, sheet_name="Train", index=False)

        # Validation
        val_df = pd.concat([x_val.reset_index(drop=True), y_val.reset_index(drop=True)], axis=1)
        val_df.to_excel(writer, sheet_name="Validation", index=False)

        # Test
        test_df = pd.concat([x_test.reset_index(drop=True), y_test.reset_index(drop=True)], axis=1)
        test_df.to_excel(writer, sheet_name="Test", index=False)

# Erstellt ein Modell und gibt dieses aus
def create_model(trial):
    """
    Creates a Keras sequential model for a given trial. The model's architecture
    and hyperparameters are dynamically generated based on the suggestions provided
    by the trial object. The model includes a flattened layer, multiple hidden layers
    with user-defined activation functions and units, and an output layer. The model
    is compiled using Huber loss, root mean squared error as a metric, and the
    AdamW optimizer configured with dynamically tuned learning rate and weight decay.

    :param trial: An Optuna trial object that suggests hyperparameter values
        for creating the model.
    :type trial: optuna.trial.Trial
    :return: A compiled Keras sequential model.
    :rtype: keras.Sequential
    """
    # Parameter
    n_layers = trial.suggest_int(name="n_Layers", low=1, high=3)
    learning_rate = trial.suggest_float(name="Learning_Rate", low=0.0001, high=1, log=True)
    weight_decay = trial.suggest_float(name="Weight_Decay", low=10e-10, high=10e-3, log=True)

    # Erstelle Model
    model = keras.Sequential()
    model.add(keras.layers.Flatten())

    # Hidden Layer
    for i in range(n_layers):
        act_func = trial.suggest_categorical("act_func_l{}".format(i), ["tanh", "relu"])
        num_hidden = trial.suggest_int("n_units_l{}".format(i), 4, 128, log=True)
        model.add(
            keras.layers.Dense(
                num_hidden,
                activation=act_func,
                kernel_regularizer=keras.regularizers.l2(weight_decay),
            )
        )

    # Ausgangslayer (Anzahl der Ausgangsparameter kann angepasst werden)
    model.add(
        keras.layers.Dense(1, kernel_regularizer=tf.keras.regularizers.l2(weight_decay))
    )

    # Model kompilieren
    model.compile(loss=keras.losses.Huber(),
                  metrics=[keras.metrics.RootMeanSquaredError()],
                  optimizer=keras.optimizers.AdamW(
                      learning_rate=learning_rate,
                      weight_decay=weight_decay,
                  )
                  )

    return model

class UnnormalizedRMSECallback(tf.keras.callbacks.Callback):
    def __init__(self, x_val, y_val, trial):
        super().__init__()
        self.x_val = x_val
        self.y_val = y_val
        self.trial = trial

    def on_epoch_end(self, epoch, logs=None):
        # Vorhersage auf Val-Daten
        y_pred = self.model.predict(self.x_val, verbose=0)

        # zurückskalieren
        y_true = unnormalize_y(self.y_val)
        y_pred = unnormalize_y(y_pred)

        # RMSE in Originaleinheit berechnen
        rmse = root_mean_squared_error(y_true, y_pred)

        # an Optuna melden
        self.trial.report(rmse, step=epoch)

        # ggf. Pruning
        if self.trial.should_prune():
            raise optuna.TrialPruned()

# Nutzt ein Modell und gibt das Ergebniss des Modells aus
def objective(trial):
    global current_model  # Reference the global model variable

    # Reproduzierbar machen
    os.environ['PYTHONHASHSEED'] = str(hpoptimize.seed)
    np.random.seed(hpoptimize.seed)
    tf.random.set_seed(hpoptimize.seed)
    tf.keras.utils.set_random_seed(hpoptimize.seed)
    tf.config.experimental.enable_op_determinism()

    # Test und Trainingsdaten einlesen
    x_train, y_train, x_val, y_val, x_test, y_test = data()

    # Erstelle Modell
    model = create_model(trial)
    current_model = model  # Update the global model reference

    # Parameter Callback
    callback = [
        keras.callbacks.EarlyStopping(
            monitor='val_root_mean_squared_error',
            patience=hpoptimize.patience,
            mode="min"),
        keras.callbacks.ModelCheckpoint(
            hpoptimize.model_file,
            monitor="val_root_mean_squared_error",
            mode="min",
            save_best_only=True,
            verbose=0),
        UnnormalizedRMSECallback(x_val, y_val, trial)
    ]

    batch_size = trial.suggest_int("Batch_Size", low=1, high=32, log=True)

    # Model fitten
    try:
        history = model.fit(
            x_train, y_train,
            validation_data=(x_val, y_val),
            batch_size=batch_size,
            epochs=hpoptimize.epochs,
            verbose=0,
            shuffle=True,
            callbacks=callback
        )
    except optuna.exceptions.TrialPruned:
        print(f"Trial {trial.number} wurde gepruned.")
        trial.set_user_attr("pruned", True)
        raise

    # Best model speichern
    if os.path.exists(hpoptimize.model_file):
        best_model = keras.models.load_model(hpoptimize.model_file)
    else:
        print("Warnung: Modelldatei nicht gefunden! Speichere das letzte Modell stattdessen.")
        best_model = model
        best_model.save(hpoptimize.model_file)

    # Evaluiere bestes Modell
    print("train: ")
    train_predict = best_model.predict(x_train)
    y_train_unnormalized = unnormalize_y(y_train)
    train_predict_unnormalized = unnormalize_y(train_predict)
    train_rmse = root_mean_squared_error(y_train_unnormalized, train_predict_unnormalized)
    train_r2 = r2_score(y_train_unnormalized, train_predict_unnormalized)
    print("val: ")
    val_predict = best_model.predict(x_val)
    y_val_unnormalized = unnormalize_y(y_val)
    val_predict_unnormalized = unnormalize_y(val_predict)
    val_rmse = root_mean_squared_error(y_val_unnormalized, val_predict_unnormalized)
    val_r2 = r2_score(y_val_unnormalized, val_predict_unnormalized)
    print("test: ")
    test_predict = best_model.predict(x_test)
    y_test_unnormalized = unnormalize_y(y_test)
    test_predict_unnormalized = unnormalize_y(test_predict)
    test_rmse = root_mean_squared_error(y_test_unnormalized, test_predict_unnormalized)
    test_r2 = r2_score(y_test_unnormalized, test_predict_unnormalized)

    # ==== Ordner robust anlegen ====
    for key in ["metrics", "plots", "models"]:
        os.makedirs(hpoptimize.paths[key], exist_ok=True)

    # Save to Excel
    save_trial_results_with_dynamic_style(
        trial.number,
        y_train_unnormalized, train_predict_unnormalized,
        y_test_unnormalized, test_predict_unnormalized,
        y_val_unnormalized, val_predict_unnormalized,
        history
    )

    # Speichere Scores für 1 Ausgang
    trial.set_user_attr("train_r2", train_r2)
    trial.set_user_attr("val_r2", val_r2)
    trial.set_user_attr("test_r2", test_r2)
    trial.set_user_attr("train_rmse", train_rmse)
    trial.set_user_attr("val_rmse", val_rmse)
    trial.set_user_attr("test_rmse", test_rmse)

    # Speichern des Models
    model_path = os.path.join(hpoptimize.paths["models"], f"{hpoptimize.study_name}_{trial.number}.keras")
    best_model.save(model_path)

    # Plotte Grafiken für Trial
    plot_graphs(
        history,
        trial.number,
        y_train_unnormalized, train_predict_unnormalized,
        y_val_unnormalized, val_predict_unnormalized,
        y_test_unnormalized, test_predict_unnormalized
    )

    # Metriken speichern
    metrics_df = pd.DataFrame({
        'Dataset': ['Train', 'Validation', 'Test'],
        'RMSE': [train_rmse, val_rmse, test_rmse],
        'R2': [train_r2, val_r2, test_r2]
    })
    metrics_df.to_csv(os.path.join(hpoptimize.paths["metrics"], f"metrics_{trial.number}.csv"), index=False)

    if np.isnan(val_rmse):
        print(f"Trial {trial.number}: val_rmse ist NaN!")

    K.clear_session()
    plt.close('all')
    gc.collect()

    return val_rmse


# Global variable to store the study
current_study = None


def save_study_results():
    """
    Save the results of the current optimization study to a directory. This function
    checks if a global variable for the current study exists, and if it does, it saves
    the trials' data as an Excel file in a specific directory named after the
    study name. Creates the directory if it does not already exist for organization
    purposes.

    :raises FileNotFoundError: If the directory path cannot be created.
    :raises PermissionError: If there are not enough permissions to write the file.
    """
    global current_study
    if current_study:
        print("\nSaving study results...")
        study_name = hpoptimize.study_name
        study_path = f"Ergebnisse/{study_name}"
        os.makedirs(study_path, exist_ok=True)  # Ensure the directory exists
        study_file = f"{study_path}/{study_name}.xlsx"
        current_study.trials_dataframe().to_excel(study_file)
        print(f"Study results saved to: {study_file}")

# Register the cleanup function
atexit.register(save_study_results)

def save_model_and_study_on_interrupt(signum, frame):
    """
    Signal handler to save the current model and study on interruption.

    This function is triggered when the program receives a specified signal,
    typically indicating an interruption, such as a keyboard interruption.
    If a model is currently loaded, it saves the model to a specified file and
    persists the study results before gracefully terminating the program.

    :param signum: Signal number associated with the interrupt event.
    :type signum: int
    :param frame: Current stack frame when the signal was received.
    :type frame: FrameType
    :return: None
    """
    global current_model, current_study
    if current_model:
        print("\nProgram interrupted. Saving the current model...")
        current_model.save("interrupted_model.keras")
        print("Model saved as 'interrupted_model.keras'.")
    save_study_results()
    print("Exiting program.")
    exit(0)

# Register the signal handler
signal.signal(signal.SIGINT, save_model_and_study_on_interrupt)

def cleanup_top10(study, trial, base_name):
    """
    Hält nur die Top-10 Trials (nach val_rmse) und löscht alle anderen Dateien.
    """
    # sortiere alle erfolgreichen Trials
    complete_trials = [t for t in study.trials if t.state == optuna.trial.TrialState.COMPLETE]
    sorted_trials = sorted(complete_trials, key=lambda t: t.value)  # kleinster RMSE = bester

    # Top 10 Trials bestimmen
    top10 = sorted_trials[:10]
    top10_ids = {t.number for t in top10}

    # aktuelle Verzeichnisse
    model_dir   = hpoptimize.paths["models"]
    plots_dir   = hpoptimize.paths["plots"]
    metrics_dir = hpoptimize.paths["metrics"]

    # welche Dateien behalten?
    keep_models  = {os.path.join(model_dir, f"{base_name}_{t.number}.keras") for t in top10}
    keep_excels  = {os.path.join(metrics_dir, f"Trial_{t.number}.xlsx") for t in top10}
    keep_metrics = {os.path.join(metrics_dir, f"metrics_{t.number}.csv") for t in top10}
    keep_plots   = {
        os.path.join(plots_dir, f"{t.number}_RMSE.png") for t in top10
    }.union({
        os.path.join(plots_dir, f"{t.number}_Huber_Loss.png") for t in top10
    }).union({
        os.path.join(plots_dir, f"{t.number}_Predict_vs._True.png") for t in top10
    })

    # löschen, was nicht in den keep-Sets ist
    for f in glob.glob(f"{model_dir}/*.keras"):
        if f not in keep_models:
            os.remove(f)
    for f in glob.glob(f"{metrics_dir}/Trial_*.xlsx"):
        if f not in keep_excels:
            os.remove(f)
    for f in glob.glob(f"{metrics_dir}/metrics_*.csv"):
        if f not in keep_metrics:
            os.remove(f)
    for f in glob.glob(f"{plots_dir}/*.png"):
        if f not in keep_plots:
            os.remove(f)

    print(f"Cleanup done → Top 10 Trials: {[t.number for t in top10]}")

# Main
def run_hpo(study_name, seed, patience, epochs, n_trials, train_data, test_data):
    """
    Execute a hyperparameter optimization (HPO) workflow using Optuna. The function initializes
    an Optuna study with specified parameters, performs optimization over a defined number
    of trials, and manages cleanup by retaining only the top 10 performing models and their
    associated plots. Intermediate output and results are stored for later analysis.

    :param study_name: The name of the study to be executed and stored.
    :type study_name: str
    :param seed: Seed value used for random operations to ensure reproducibility.
    :type seed: int
    :param patience: Early stopping patience setting for training.
    :type patience: int
    :param epochs: Maximum number of epochs for model training.
    :type epochs: int
    :param n_trials: Number of optimization trials to perform.
    :type n_trials: int
    :param train_data: The training dataset to be used for model training and evaluation.
    :type train_data: Any
    :return: None
    """
    global current_study
    initialize(study_name, seed, patience, epochs, n_trials, train_data, test_data)

    # Ergebnisse-Unterordner für bessere Struktur
    base_dir = f"Ergebnisse/{hpoptimize.study_name}"
    hpoptimize.paths = {
        "base": base_dir,
        "models": os.path.join(base_dir, "models"),
        "plots": os.path.join(base_dir, "plots"),
        "metrics": os.path.join(base_dir, "metrics"),
        "data": os.path.join(base_dir, "data")
    }
    for path in hpoptimize.paths.values():
        os.makedirs(path, exist_ok=True)

    # Lade normalisierte Daten
    x_train, y_train, x_val, y_val, x_test, y_test = data()
    save_split_data(x_train, y_train, x_val, y_val, x_test, y_test)

    # Unnormalisierte Daten zum Vergleich speichern
    save_split_data(
        unnormalize_x(x_train),
        unnormalize_y(y_train),
        unnormalize_x(x_val),
        unnormalize_y(y_val),
        unnormalize_x(x_test),
        unnormalize_y(y_test)
    )

    sampler = optuna.samplers.TPESampler(seed=hpoptimize.seed, multivariate=True, n_startup_trials=50)
    pruner = optuna.pruners.MedianPruner(
            n_startup_trials=200,
            n_warmup_steps=300,
            interval_steps=25
        )

    """pruner = get_dynamic_pruner(n_trials=hpoptimize.n_trials, epochs=hpoptimize.epochs, strategy="balanced")"""

    study = optuna.create_study(
        direction="minimize",
        sampler=sampler,
        pruner=pruner,
        study_name=hpoptimize.study_name,
        storage=f"sqlite:///{os.path.join(base_dir, hpoptimize.study_name + '.sqlite3')}",
        load_if_exists=True
    )

    def per_trial_callback(study, trial):
        cleanup_top10(study, trial, hpoptimize.study_name)

    current_study = study
    study.optimize(objective, n_trials=hpoptimize.n_trials,
                   callbacks=[per_trial_callback])

    save_study_results()

    # Delete all models except the best 10
    print("Deleting models except the best 10...")
    top_10_trials = [t for t in study.trials if t.state == optuna.trial.TrialState.COMPLETE]
    top_10_trials = sorted(top_10_trials, key=lambda t: t.value)[:10]

    if not top_10_trials:
        print("Warnung: Keine erfolgreichen Trials gefunden. Es werden keine Modelle oder Plots gelöscht.")
        return  # Löschen überspringen

    top_10_model_files = {
        os.path.join(hpoptimize.paths["models"], f"{hpoptimize.study_name}_{trial.number}.keras")
        for trial in top_10_trials
    }
    top_10_plot_files = {
        os.path.join(hpoptimize.paths["plots"], f"{trial.number}_RMSE.png") for trial in top_10_trials
    }.union({
        os.path.join(hpoptimize.paths["plots"], f"{trial.number}_Huber_Loss.png") for trial in top_10_trials
    }).union({
        os.path.join(hpoptimize.paths["plots"], f"{trial.number}_Predict_vs._True.png") for trial in top_10_trials
    })

    # Alle Dateien finden
    all_model_files = glob.glob(f"{hpoptimize.paths['models']}/*.keras")
    """all_plot_files = glob.glob(f"Ergebnisse/{hpoptimize.study_name}/*_RMSE.png") + \
                     glob.glob(f"Ergebnisse/{hpoptimize.study_name}/*_Huber.png") + \
                     glob.glob(f"Ergebnisse/{hpoptimize.study_name}/*_predict_vs_True.png")"""
    all_plot_files = glob.glob(f"{hpoptimize.paths['plots']}/*.png")

    print("Top 10 Trials (nach val_rmse):")
    for t in top_10_trials:
        print(f"Trial {t.number}: value = {t.value}")

    print("Alle gespeicherten Modell-Dateien:")
    for file in all_model_files:
        print(" -", file)

    print("Top 10 erlaubte Modelle:")
    for file in top_10_model_files:
        print(" ✓", file)

    # Lösche alle, die nicht zu den besten gehören
    deleted_models = 0
    deleted_plots = 0

    for model_file in all_model_files:
        if model_file not in top_10_model_files:
            if os.path.basename(model_file).startswith(hpoptimize.study_name):
                try:
                    os.remove(model_file)
                    print(f"Modell gelöscht: {model_file}")
                    deleted_models += 1
                except FileNotFoundError:
                    pass

    # Plots löschen
    for plot_file in all_plot_files:
        if plot_file not in top_10_plot_files:
            try:
                os.remove(plot_file)
                print(f"Plot gelöscht: {plot_file}")
                deleted_plots += 1
            except FileNotFoundError:
                pass

    print(f"Cleanup abgeschlossen: {deleted_models} Modelle und {deleted_plots} Plots wurden gelöscht.")


if __name__ == '__main__':
    # Set the path to the mplstyle file and adjust it for different dataset
    holdout_data = r"Getrennte_Daten/Holdout_fixed_Modell_1.xlsx"
    pool_data = r"Getrennte_Daten/Pool_Halton_Modell_1.xlsx"

    study_name = "Study_24_09_2025_Halton_Modell_1.3_KS_Holdout_seed_999"

    # Adjust the parameters and the Study name
    run_hpo(study_name=study_name, seed=999, patience=100, n_trials=500, epochs=1000,
            train_data=pool_data, test_data=holdout_data)